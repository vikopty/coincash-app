import React from 'react';
import { ThemeProvider } from '@/components/ThemeProvider';
import WalletAnalyzer from './components/WalletAnalyzer';
import { Toaster } from '@/components/ui/sonner';

export default function App() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-4">
        <WalletAnalyzer />
      </div>
      <Toaster />
    </ThemeProvider>
  );
}
