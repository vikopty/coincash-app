import { supabase } from '../lib/supabase';

/**
 * Interface for Analysis Result
 * {
 *   source: string,
 *   status: 'SAFE' | 'DANGEROUS' | 'UNVERIFIED',
 *   details: string
 * }
 */

// Etherscan Integration
const checkEtherscan = async (wallet) => {
  const apiKey = import.meta.env.VITE_ETHERSCAN_API_KEY;
  if (!apiKey) {
    return { source: 'Etherscan', status: 'UNVERIFIED', details: 'API Key missing' };
  }
  
  try {
    const response = await fetch(
      `https://api.etherscan.io/api?module=account&action=txlist&address=${wallet}&startblock=0&endblock=99999999&page=1&offset=10&sort=desc&apikey=${apiKey}`
    );
    const data = await response.json();

    if (data.status === '0') {
        if (data.message === 'No transactions found') {
            return { source: 'Etherscan', status: 'UNVERIFIED', details: 'No transactions found' };
        }
        return { source: 'Etherscan', status: 'UNVERIFIED', details: data.result || 'API Error' };
    }

    if (data.status === '1' && Array.isArray(data.result)) {
       return { 
         source: 'Etherscan', 
         status: 'SAFE', 
         details: `Active wallet with ${data.result.length}+ recent transactions` 
       };
    }

    return { source: 'Etherscan', status: 'UNVERIFIED', details: 'Could not verify' };
  } catch (error) {
    console.error('Etherscan check failed:', error);
    return { source: 'Etherscan', status: 'UNVERIFIED', details: 'Connection failed' };
  }
};

// BlockScout Integration
const checkBlockScout = async (wallet) => {
  try {
    // Using BlockScout V2 API
    const response = await fetch(`https://eth.blockscout.com/api/v2/addresses/${wallet}`);
    
    if (!response.ok) {
        return { source: 'BlockScout', status: 'UNVERIFIED', details: 'Address not found' };
    }

    const data = await response.json();
    
    if (data && (data.hash || data.address)) {
        const type = data.is_contract ? 'Contract' : 'Wallet';
        return { source: 'BlockScout', status: 'SAFE', details: `Verified ${type} on BlockScout` };
    }
    
    return { source: 'BlockScout', status: 'UNVERIFIED', details: 'No data found' };
  } catch (error) {
    console.error('BlockScout check failed:', error);
    return { source: 'BlockScout', status: 'UNVERIFIED', details: 'Connection failed' };
  }
};

// MistTrack Placeholder
const checkMistTrack = async (wallet) => {
  // TODO: Integrate real API with import.meta.env.VITE_MISTTRACK_API_KEY
  await new Promise(resolve => setTimeout(resolve, 500));
  return { source: 'MistTrack', status: 'UNVERIFIED', details: 'Pending API integration' };
};

// Bitrace Placeholder
const checkBitrace = async (wallet) => {
  // TODO: Integrate real API with import.meta.env.VITE_BITRACE_API_KEY
  await new Promise(resolve => setTimeout(resolve, 600));
  return { source: 'Bitrace', status: 'UNVERIFIED', details: 'Pending API integration' };
};

// AMLBot Placeholder
const checkAMLBot = async (wallet) => {
  // TODO: Integrate real API with import.meta.env.VITE_AMLBOT_API_KEY
  await new Promise(resolve => setTimeout(resolve, 400));
  return { source: 'AMLBot', status: 'UNVERIFIED', details: 'Pending API integration' };
};

export const analyzeWallet = async (walletAddress) => {
  try {
    // 1. Run all checks in parallel
    const checks = await Promise.all([
      checkEtherscan(walletAddress),
      checkBlockScout(walletAddress),
      checkMistTrack(walletAddress),
      checkBitrace(walletAddress),
      checkAMLBot(walletAddress)
    ]);

    // 2. Determine final status
    const dangerousCheck = checks.find(check => check.status === 'DANGEROUS');
    
    // Risk APIs that must be verified to consider the wallet SAFE
    const riskSources = ['MistTrack', 'Bitrace', 'AMLBot'];
    
    // Check if we have at least one SAFE result from a dedicated risk API
    const safeRiskCheck = checks.find(check => 
      riskSources.includes(check.source) && check.status === 'SAFE'
    );
    
    let finalResult = 'UNVERIFIED';
    let riskScore = 50; // Neutral score for unverified

    if (dangerousCheck) {
      finalResult = 'DANGEROUS';
      riskScore = 85;
    } else if (safeRiskCheck) {
      // Only mark as SAFE if we have confirmation from a risk database
      finalResult = 'SAFE';
      riskScore = 10;
    }
    // Otherwise remains UNVERIFIED (even if Etherscan is SAFE)


    // 3. Save to Supabase
    const { error } = await supabase
      .from('analysis_history')
      .insert([{
        wallet_address: walletAddress,
        result: finalResult,
        risk_score: riskScore,
        details: checks
      }]);

    if (error) {
      console.error('Error saving analysis:', error);
      // Proceed even if save fails, but log it
    }

    return {
      result: finalResult,
      riskScore,
      checks,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    console.error('Analysis failed:', error);
    throw new Error('Failed to analyze wallet');
  }
};

export const getHistory = async () => {
  try {
    const { data, error } = await supabase
      .from('analysis_history')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(5);
      
    if (error) {
      console.error('Error fetching history:', error);
      return [];
    }
    
    return data || [];
  } catch (error) {
    console.error('History fetch failed:', error);
    return [];
  }
};
