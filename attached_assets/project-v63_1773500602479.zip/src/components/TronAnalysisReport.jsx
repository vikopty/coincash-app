import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { motion } from 'framer-motion';
import { Shield, AlertTriangle, ArrowRightLeft, Clock, History, Ban, ShieldAlert } from 'lucide-react';

const TronAnalysisReport = ({ reportData }) => {
  const {
    balanceUSDT = 0,
    totalTx = 0,
    txIn = 0,
    txOut = 0,
    dateCreated = Date.now(),
    lastTxDate = Date.now(),
    totalInUSDT = 0,
    totalOutUSDT = 0,
    uniqueWalletsCount = 0,
    transfersAnalyzed = 0,
    exchangeInteractions = 0
  } = reportData || {};

  const creationDate = dateCreated ? new Date(dateCreated) : new Date();
  const today = new Date();
  const diffTime = Math.abs(today - creationDate);
  const daysSinceCreation = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  // Calculate Risk Score
  let riskScore = 0;
  
  // 1. Wallet age
  if (daysSinceCreation < 30) riskScore += 20;
  else if (daysSinceCreation <= 180) riskScore += 10;
  
  // 2. Total volume
  const totalVolumeUSDT = totalInUSDT + totalOutUSDT;
  if (totalVolumeUSDT > 1000000) riskScore += 25;
  else if (totalVolumeUSDT > 100000) riskScore += 15;
  
  // 3. Counterparties
  if (uniqueWalletsCount > 200) riskScore += 20;
  else if (uniqueWalletsCount > 50) riskScore += 10;
  
  // 4. Transaction frequency
  if (totalTx > 500) riskScore += 20;
  else if (totalTx > 100) riskScore += 10;
  
  // 5. Exchange interaction
  if (transfersAnalyzed > 0 && exchangeInteractions > (transfersAnalyzed * 0.5)) {
    riskScore -= 10;
  }
  
  // Normalize 0-100
  riskScore = Math.max(0, Math.min(100, riskScore));
  
  // Classification
  let riskLevel = '';
  let riskColor = '';
  
  if (riskScore <= 25) {
    riskLevel = 'Riesgo Bajo';
    riskColor = 'text-green-500';
  } else if (riskScore <= 50) {
    riskLevel = 'Riesgo Moderado';
    riskColor = 'text-yellow-500';
  } else if (riskScore <= 75) {
    riskLevel = 'Riesgo Alto';
    riskColor = 'text-orange-500';
  } else {
    riskLevel = 'Riesgo Severo';
    riskColor = 'text-red-500';
  }
  
  const formattedCreationDate = creationDate.toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric' });
  const formattedBalance = balanceUSDT.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const formattedIn = totalInUSDT.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const formattedOut = totalOutUSDT.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 mt-8 animate-in fade-in duration-500">
      
      {/* 1. Network Information Card & 2. Risk Score Gauge */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground uppercase tracking-wider">Información de Red</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full overflow-hidden bg-background flex items-center justify-center p-2 border">
                <img 
                  src="https://sensible-spoonbill-485.convex.cloud/api/storage/df067b94-1243-45f9-a375-65c87e96e568" 
                  alt="TRON Logo" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <div className="text-2xl font-bold">Red: TRON</div>
                <div className="text-sm text-muted-foreground">USDT (TRC20)</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground uppercase tracking-wider">Puntuación de Riesgo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-end">
                <span className={`text-3xl font-bold ${riskColor}`}>{riskScore}/100</span>
                <span className={`text-sm font-medium ${riskColor}`}>{riskLevel}</span>
              </div>
              <div className="w-full h-3 bg-secondary rounded-full overflow-hidden flex relative">
                <div className={`h-full bg-green-500 w-1/4 ${riskScore <= 0 ? 'opacity-20' : ''}`}></div>
                <div className={`h-full bg-yellow-500 w-1/4 ${riskScore <= 25 ? 'opacity-20' : ''}`}></div>
                <div className={`h-full bg-orange-500 w-1/4 ${riskScore <= 50 ? 'opacity-20' : ''}`}></div>
                <div className={`h-full bg-red-500 w-1/4 ${riskScore <= 75 ? 'opacity-20' : ''}`}></div>
                
                <div 
                  className="absolute top-0 bottom-0 w-1 bg-background"
                  style={{ left: `calc(${riskScore}% - 2px)` }}
                ></div>
              </div>
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>Bajo</span>
                <span>Moderado</span>
                <span>Alto</span>
                <span>Severo</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 3. Summary Section */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-lg">
            <History className="w-5 h-5 text-primary" />
            Resumen de Actividad
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="space-y-1 bg-background/50 p-3 rounded-lg border border-border/50">
              <span className="text-xs text-muted-foreground">Estado</span>
              <div className="font-semibold flex items-center gap-1.5 text-green-500">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                Activo
              </div>
            </div>
            <div className="space-y-1 bg-background/50 p-3 rounded-lg border border-border/50">
              <span className="text-xs text-muted-foreground">Balance Total</span>
              <div className="font-semibold text-lg">{formattedBalance} USDT</div>
            </div>
            <div className="space-y-1 bg-background/50 p-3 rounded-lg border border-border/50">
              <span className="text-xs text-muted-foreground">Wallet creada</span>
              <div className="font-medium text-sm">{formattedCreationDate}</div>
            </div>
            <div className="space-y-1 bg-background/50 p-3 rounded-lg border border-border/50">
              <span className="text-xs text-muted-foreground">Días de creada</span>
              <div className="font-medium text-sm">{daysSinceCreation} días</div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <div className="bg-background/50 p-4 rounded-lg border border-border/50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-green-500/10 text-green-500 rounded-full">
                  <ArrowRightLeft className="w-5 h-5 rotate-90" />
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Entradas Totales</div>
                  <div className="font-bold text-xl">{formattedIn} USDT</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-medium">{txIn} Txns</div>
              </div>
            </div>
            
            <div className="bg-background/50 p-4 rounded-lg border border-border/50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-red-500/10 text-red-500 rounded-full">
                  <ArrowRightLeft className="w-5 h-5 -rotate-90" />
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Salidas Totales</div>
                  <div className="font-bold text-xl">{formattedOut} USDT</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-medium">{txOut} Txns</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 4. Risk Counterparties Section */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-lg">
            <AlertTriangle className="w-5 h-5 text-orange-500" />
            Contrapartes de Riesgo
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { addr: "TVJ7RN...9kLQ", tags: ["high value", "suspicious"], amount: "25,000 USDT" },
              { addr: "TQ8xWM...2mPz", tags: ["high frequency"], amount: "1,200 USDT" },
              { addr: "TR5xQL...8vNx", tags: ["frozen"], amount: "50,000 USDT" }
            ].map((cp, idx) => (
              <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded-lg border border-border/50 bg-background/30 gap-3">
                <div className="font-mono text-sm">{cp.addr}</div>
                <div className="flex flex-wrap gap-2">
                  {cp.tags.map(tag => {
                    let variant = "secondary";
                    let label = tag;
                    if (tag === "high value") { variant = "default"; label = "Alto Valor"; }
                    if (tag === "high frequency") { variant = "outline"; label = "Alta Frecuencia"; }
                    if (tag === "suspicious") { variant = "destructive"; label = "Sospechoso"; }
                    if (tag === "frozen") { variant = "destructive"; label = "Congelado"; }
                    
                    return (
                      <Badge key={tag} variant={variant} className={tag === 'high value' ? 'bg-blue-500 hover:bg-blue-600' : ''}>
                        {label}
                      </Badge>
                    );
                  })}
                </div>
                <div className="text-sm font-medium text-right">{cp.amount}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 5. Freeze/Sanction Section */}
      <Card className="border-red-500/20">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-lg text-red-500">
            <Ban className="w-5 h-5" />
            Congelamientos y Sanciones
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader className="bg-muted/50">
                <TableRow>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Fecha de Operación</TableHead>
                  <TableHead>Historial</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium text-red-500">Congelado</TableCell>
                  <TableCell>20-06-2025</TableCell>
                  <TableCell className="text-muted-foreground text-sm">Dirección marcada por actividad ilícita relacionada con mezcladores.</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium text-orange-500">Advertencia</TableCell>
                  <TableCell>15-02-2024</TableCell>
                  <TableCell className="text-muted-foreground text-sm">Interacción con billetera de alto riesgo reportada.</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* 6. Legal Notice Section */}
      <div className="bg-muted/30 p-4 rounded-lg border border-border/50 mt-8 mb-12 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-muted-foreground shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground leading-relaxed">
          <strong className="text-foreground">Aviso Legal:</strong> La información proporcionada en este informe es generada a partir de datos on-chain y bases de datos públicas de terceros. CoinCashWalletGuard no garantiza la exactitud absoluta, integridad o actualidad de los datos. Esta información tiene fines puramente analíticos e informativos, y no constituye asesoramiento financiero, legal ni recomendación de inversión. El usuario asume toda la responsabilidad por las decisiones tomadas en base a este análisis. En caso de dudas sobre la legalidad de los fondos, consulte con un profesional legal o las autoridades competentes.
        </p>
      </div>

    </div>
  );
};

export default TronAnalysisReport;
