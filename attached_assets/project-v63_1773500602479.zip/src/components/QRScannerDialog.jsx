import React, { useEffect, useRef, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Html5Qrcode } from 'html5-qrcode';
import { Upload, Camera, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

const QRScannerDialog = ({ open, onOpenChange, onScanSuccess }) => {
  const [isScanning, setIsScanning] = useState(false);
  const [hasCameraError, setHasCameraError] = useState(false);
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const scannerRef = useRef(null);
  const html5QrCodeRef = useRef(null);
  const fileInputRef = useRef(null);
  const isTransitioningRef = useRef(false);

  useEffect(() => {
    let isMounted = true;
    
    if (open) {
      // Small delay to allow DialogContent to mount in the DOM
      setTimeout(() => {
        if (isMounted) startCamera();
      }, 100);
    } else {
      stopCamera();
    }
    
    return () => {
      isMounted = false;
      stopCamera();
    };
  }, [open]);

  const startCamera = async () => {
    if (isTransitioningRef.current) return;
    
    setHasCameraError(false);
    setIsScanning(true);
    
    // Wait for the element to be available in the DOM
    let attempts = 0;
    while (!document.getElementById("qr-reader") && attempts < 20) {
      await new Promise(resolve => setTimeout(resolve, 100));
      attempts++;
    }

    if (!document.getElementById("qr-reader")) {
      console.error("Camera start error: HTML Element with id=qr-reader not found");
      setHasCameraError(true);
      setIsScanning(false);
      return;
    }

    try {
      isTransitioningRef.current = true;
      
      if (!html5QrCodeRef.current) {
        html5QrCodeRef.current = new Html5Qrcode("qr-reader");
      }
      
      // If already scanning, don't start again
      if (html5QrCodeRef.current.isScanning) {
        isTransitioningRef.current = false;
        return;
      }
      
      await html5QrCodeRef.current.start(
        { facingMode: "environment" },
        {
          fps: 10,
          qrbox: { width: 250, height: 250 },
        },
        async (decodedText) => {
          if (!isTransitioningRef.current) {
            await stopCamera();
            onScanSuccess(decodedText);
            onOpenChange(false);
          }
        },
        (errorMessage) => {
          // Ignore parse errors, they happen continuously when scanning
        }
      );
    } catch (err) {
      console.error("Camera start error:", err);
      setHasCameraError(true);
      setIsScanning(false);
    } finally {
      isTransitioningRef.current = false;
    }
  };

  const stopCamera = async () => {
    if (isTransitioningRef.current) {
      // If currently starting, wait briefly before attempting to stop
      let waitAttempts = 0;
      while (isTransitioningRef.current && waitAttempts < 10) {
        await new Promise(resolve => setTimeout(resolve, 200));
        waitAttempts++;
      }
    }

    if (!html5QrCodeRef.current) {
      setIsScanning(false);
      return;
    }

    try {
      isTransitioningRef.current = true;
      if (html5QrCodeRef.current.isScanning || html5QrCodeRef.current.getState() === 2) {
        await html5QrCodeRef.current.stop();
        html5QrCodeRef.current.clear();
      }
    } catch (err) {
      console.error("Failed to stop camera:", err);
    } finally {
      isTransitioningRef.current = false;
      setIsScanning(false);
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsProcessingFile(true);
    try {
      if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
        await stopCamera();
      }
      
      let attempts = 0;
      while (!document.getElementById("qr-reader") && attempts < 20) {
        await new Promise(resolve => setTimeout(resolve, 100));
        attempts++;
      }
      
      if (!html5QrCodeRef.current) {
        html5QrCodeRef.current = new Html5Qrcode("qr-reader");
      }
      
      const decodedText = await html5QrCodeRef.current.scanFileV2(file);
      onScanSuccess(decodedText.decodedText || decodedText);
      onOpenChange(false);
    } catch (err) {
      console.error("File scan error:", err);
      toast.error("No se pudo detectar un código QR en la imagen. Intenta con otra foto.");
    } finally {
      setIsProcessingFile(false);
      // Reset input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const retryCamera = () => {
    startCamera();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md flex flex-col items-center">
        <DialogHeader className="text-center w-full">
          <DialogTitle className="text-center">Escanear código QR</DialogTitle>
          <DialogDescription className="text-center">
            Apunta la cámara al código QR de la billetera.
          </DialogDescription>
        </DialogHeader>

        <div className="w-full relative min-h-[300px] flex flex-col items-center justify-center bg-black/5 rounded-lg overflow-hidden border">
          <div id="qr-reader" className="w-full h-full" />
          
          {hasCameraError && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/80 p-6 text-center z-10">
              <Camera className="w-12 h-12 text-muted-foreground mb-4" />
              <p className="text-sm font-medium mb-2">No se pudo acceder a la cámara</p>
              <p className="text-xs text-muted-foreground mb-4">
                Por favor, verifica los permisos de la cámara en tu navegador.
              </p>
              <Button onClick={retryCamera} variant="outline" size="sm">
                Reintentar
              </Button>
            </div>
          )}
        </div>

        <div className="flex flex-col gap-3 w-full mt-2">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">O</span>
            </div>
          </div>

          <Button 
            variant="outline" 
            className="w-full" 
            onClick={triggerFileInput}
            disabled={isProcessingFile}
          >
            {isProcessingFile ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Upload className="w-4 h-4 mr-2" />
            )}
            Buscar QR en una foto
          </Button>
          <input 
            type="file" 
            ref={fileInputRef} 
            accept="image/*" 
            className="hidden" 
            onChange={handleFileUpload}
          />
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default QRScannerDialog;