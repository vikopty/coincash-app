import React from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import { CheckCircle2, AlertTriangle, ShieldCheck, Skull } from 'lucide-react';

const AnalysisResult = ({ result, checks }) => {
  if (!result) return null;

  const isSafe = result === 'SAFE';
  const isDangerous = result === 'DANGEROUS';
  const isUnverified = result === 'UNVERIFIED';

  let borderColor = 'border-yellow-500 bg-yellow-50/10';
  let titleColor = 'text-yellow-600';
  let icon = <AlertTriangle className="w-16 h-16 text-yellow-500" />;
  let description = 'Risk level Unknown. Unable to verify with risk databases.';

  if (isSafe) {
    borderColor = 'border-green-500 bg-green-50/10';
    titleColor = 'text-green-600';
    icon = <ShieldCheck className="w-16 h-16 text-green-500" />;
    description = 'No risks detected across monitored databases.';
  } else if (isDangerous) {
    borderColor = 'border-red-500 bg-red-50/10';
    titleColor = 'text-red-600';
    icon = <Skull className="w-16 h-16 text-red-500" />;
    description = 'High risk activity detected. Proceed with caution.';
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      className="w-full max-w-md mt-6"
    >
      <Card className={`border-2 ${borderColor}`}>
        <CardHeader className="text-center pb-2">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
            className="flex justify-center mb-2"
          >
            {icon}
          </motion.div>
          <CardTitle className={`text-3xl font-bold ${titleColor}`}>
            {result}
          </CardTitle>
          <CardDescription>
            {description}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 mt-4">
            {checks && checks.map((check, index) => {
              let badgeVariant = 'outline';
              let iconColor = 'text-gray-500';
              let statusIcon = <CheckCircle2 className="w-5 h-5 text-gray-500 mt-0.5" />;

              if (check.status === 'SAFE') {
                badgeVariant = 'outline';
                iconColor = 'text-green-500';
                statusIcon = <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5" />;
              } else if (check.status === 'DANGEROUS') {
                badgeVariant = 'destructive';
                iconColor = 'text-red-500';
                statusIcon = <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5" />;
              } else {
                badgeVariant = 'secondary';
                iconColor = 'text-yellow-500';
                statusIcon = <AlertTriangle className="w-5 h-5 text-yellow-500 mt-0.5" />;
              }

              return (
                <div key={index} className="flex items-start gap-3 p-2 rounded-lg bg-background/50 border">
                  {statusIcon}
                  <div className="flex-1">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-sm">{check.source}</span>
                      <Badge variant={badgeVariant} className="text-[10px] h-5">
                        {check.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{check.details}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default AnalysisResult;
