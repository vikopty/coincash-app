import React, { useState } from 'react';
import { Search, Loader2, QrCode } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import TronAnalysisReport from './TronAnalysisReport';
import QRScannerDialog from './QRScannerDialog';
const WalletAnalyzer = () => {
  const [address, setAddress] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [reportData, setReportData] = useState(null);
  const isValidTronAddress = addr => {
    return /^T[a-zA-Z0-9]{33}$/.test(addr);
  };
  const fetchTronData = async addr => {
    try {
      if (!isValidTronAddress(addr)) {
        throw new Error("Invalid TRON address format");
      }
      const usdtContract = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';

      // 1. Account Info (Balance, creation date)
      const accountRes = await fetch(`https://apilist.tronscanapi.com/api/account?address=${encodeURIComponent(addr)}`);
      if (!accountRes.ok) throw new Error(`API Error: ${accountRes.status}`);
      const accountData = await accountRes.json();
      const usdtToken = accountData.trc20token_balances?.find(t => t.tokenId === usdtContract);
      const balanceUSDT = usdtToken ? parseFloat(usdtToken.balance) / Math.pow(10, usdtToken.tokenDecimal) : 0;
      const dateCreated = accountData.date_created || Date.now();

      // 2. Account Stats (Total tx, in, out)
      const statsRes = await fetch(`https://apilist.tronscanapi.com/api/account/stats?address=${encodeURIComponent(addr)}`);
      let totalTx = 0,
        txIn = 0,
        txOut = 0;
      if (statsRes.ok) {
        const statsData = await statsRes.json();
        totalTx = statsData.transactions || 0;
        txIn = statsData.transactions_in || 0;
        txOut = statsData.transactions_out || 0;
      }

      // 3. Latest transaction timestamp
      const latestTxRes = await fetch(`https://apilist.tronscanapi.com/api/transaction?sort=-timestamp&count=true&limit=1&start=0&address=${encodeURIComponent(addr)}`);
      let lastTxDate = Date.now();
      if (latestTxRes.ok) {
        const latestTxData = await latestTxRes.json();
        lastTxDate = latestTxData.data && latestTxData.data.length > 0 ? latestTxData.data[0].timestamp : Date.now();
      }

      // 4. USDT Transfers for volume and unique wallets
      let totalInUSDT = 0;
      let totalOutUSDT = 0;
      const uniqueWallets = new Set();
      let transfers = [];
      let exchangeInteractions = 0;

      // Fetch up to 3 pages sequentially to avoid rate limits (3 requests per sec)
      const maxPages = 3;
      for (let i = 0; i < maxPages; i++) {
        const res = await fetch(`https://apilist.tronscanapi.com/api/token_trc20/transfers?limit=50&start=${i * 50}&sort=-timestamp&count=true&relatedAddress=${encodeURIComponent(addr)}&contract_address=${usdtContract}`);
        if (!res.ok) break;
        const data = await res.json();
        if (data.token_transfers && data.token_transfers.length > 0) {
          transfers = transfers.concat(data.token_transfers);
        }
        if (!data.token_transfers || data.token_transfers.length < 50) {
          break; // No more pages
        }
      }
      transfers.forEach(t => {
        const amount = parseFloat(t.quant) / Math.pow(10, t.tokenInfo.tokenDecimal);
        if (t.to_address === addr) {
          totalInUSDT += amount;
        } else if (t.from_address === addr) {
          totalOutUSDT += amount;
        }
        const isFromExchange = t.from_address_tag && t.from_address_tag.from_address_tag;
        const isToExchange = t.to_address_tag && t.to_address_tag.to_address_tag;
        if (isFromExchange || isToExchange) {
          exchangeInteractions++;
        }
        uniqueWallets.add(t.from_address);
        uniqueWallets.add(t.to_address);
      });
      uniqueWallets.delete(addr);
      uniqueWallets.delete('');
      return {
        address: addr,
        balanceUSDT,
        totalTx,
        txIn,
        txOut,
        dateCreated,
        lastTxDate,
        totalInUSDT,
        totalOutUSDT,
        uniqueWalletsCount: uniqueWallets.size,
        transfersAnalyzed: transfers.length,
        exchangeInteractions
      };
    } catch (error) {
      console.error("Error fetching Tron data:", error);
      return null;
    }
  };
  const handleSearch = async e => {
    e.preventDefault();
    if (!address) return;
    setIsAnalyzing(true);
    setShowReport(false);
    const data = await fetchTronData(address);
    if (data) {
      setReportData(data);
      setShowReport(true);
    } else {
      // In case of error or invalid address, we can show a fallback or error
      // But for this requirement we just show the report with empty/zero data if failed
      setReportData({
        address,
        balanceUSDT: 0,
        totalTx: 0,
        txIn: 0,
        txOut: 0,
        dateCreated: Date.now(),
        lastTxDate: Date.now(),
        totalInUSDT: 0,
        totalOutUSDT: 0,
        uniqueWalletsCount: 0,
        transfersAnalyzed: 0,
        exchangeInteractions: 0
      });
      setShowReport(true);
    }
    setIsAnalyzing(false);
  };
  const handleScanSuccess = scannedAddress => {
    setAddress(scannedAddress);
    setIsScannerOpen(false);
  };
  return <div className="flex flex-col items-center w-full max-w-4xl px-4 py-8 mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="text-center mb-8 w-full">
        <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl mb-1">
          Coin<span className="text-primary">Cash</span>
        </h1>
        
        <div className="flex items-center justify-center gap-1.5 mb-8 animate-in fade-in slide-in-from-bottom-2 duration-700 delay-100" style={{
        color: "rgb(31, 189, 20)",
        backgroundColor: "rgba(0, 0, 0, 0)",
        fontSize: "20px",
        fontFamily: "ui-sans-serif, system-ui, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\"",
        fontWeight: "400",
        textAlign: "center"
      }}>
          WalletGuard
        </div>

        {/* Search Section */}
        <Card className="w-full max-w-2xl mx-auto shadow-sm border-border/50 bg-card/50 backdrop-blur-sm">
          <CardContent className="p-6">
            <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
                <Input type="text" placeholder="Ingrese dirección TRC20 (ej. T...)" className="pl-10 h-12 bg-background border-input focus-visible:ring-primary text-base" value={address} onChange={e => {
                setAddress(e.target.value);
                if (!e.target.value) setShowReport(false);
              }} />
              </div>
              
              <Button type="button" variant="outline" className="h-12 px-4 shrink-0" onClick={() => setIsScannerOpen(true)}>
                <QrCode className="w-5 h-5 mr-2" />
                Escanear QR
              </Button>

              <Button type="submit" size="lg" className="h-12 w-full sm:w-auto min-w-[140px]" disabled={isAnalyzing}>
                {isAnalyzing ? <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analizando
                  </> : 'Analizar dirección'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
      
      {/* Analysis Report */}
      <div className="w-full">
        {showReport ? <TronAnalysisReport reportData={reportData} /> : <div className="flex justify-center items-center py-12 px-4 animate-in fade-in duration-500">
            <p className="text-muted-foreground text-center text-lg" style={{
          color: "rgb(163, 163, 163)",
          backgroundColor: "rgba(0, 0, 0, 0)",
          fontSize: "18px",
          fontFamily: "ui-sans-serif, system-ui, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\"",
          fontWeight: "400",
          textAlign: "center",
          margin: "0px",
          marginTop: "0px",
          marginRight: "0px",
          marginBottom: "0px",
          marginLeft: "0px",
          padding: "0px",
          paddingTop: "0px",
          paddingRight: "0px",
          paddingBottom: "0px",
          paddingLeft: "0px",
          borderRadius: "0px",
          border: "0px solid rgb(26, 26, 26)",
          borderWidth: "0px",
          borderColor: "rgb(26, 26, 26)",
          borderStyle: "solid",
          width: "422.719px",
          height: "28px",
          display: "block",
          position: "static",
          top: "auto",
          right: "auto",
          bottom: "auto",
          left: "auto"
        }}></p>
          </div>}
      </div>

      <QRScannerDialog open={isScannerOpen} onOpenChange={setIsScannerOpen} onScanSuccess={handleScanSuccess} />
    </div>;
};
export default WalletAnalyzer;