import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const HistoryList = ({ history }) => {
  if (!history || history.length === 0) return null;

  return (
    <Card className="w-full max-w-md mt-8">
      <CardHeader>
        <CardTitle className="text-lg font-medium">Recent Analysis</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {history.map((item) => (
            <div key={item.id} className="flex items-center justify-between border-b pb-2 last:border-0 last:pb-0">
              <div className="flex flex-col">
                <span className="font-mono text-xs text-muted-foreground truncate w-40 sm:w-64" title={item.wallet_address}>
                  {item.wallet_address}
                </span>
                <span className="text-[10px] text-muted-foreground">
                  {new Date(item.created_at).toLocaleDateString()} {new Date(item.created_at).toLocaleTimeString()}
                </span>
              </div>
              <Badge 
                variant={item.result === 'SAFE' ? 'default' : 'destructive'}
                className={item.result === 'SAFE' ? 'bg-green-600 hover:bg-green-700' : ''}
              >
                {item.result}
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default HistoryList;
