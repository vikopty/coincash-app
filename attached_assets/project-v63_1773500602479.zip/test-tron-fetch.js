const fetchTronData = async (addr) => {
  try {
    const usdtContract = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';
    
    const accountRes = await fetch(`https://apilist.tronscanapi.com/api/account?address=${addr}`, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    const accountData = await accountRes.json();
    const usdtToken = accountData.trc20token_balances?.find(t => t.tokenId === usdtContract);
    const balanceUSDT = usdtToken ? parseFloat(usdtToken.balance) / Math.pow(10, usdtToken.tokenDecimal) : 0;
    const dateCreated = accountData.date_created;
    
    const statsRes = await fetch(`https://apilist.tronscanapi.com/api/account/stats?address=${addr}`, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    const statsData = await statsRes.json();
    const totalTx = statsData.transactions || 0;
    const txIn = statsData.transactions_in || 0;
    const txOut = statsData.transactions_out || 0;
    
    const latestTxRes = await fetch(`https://apilist.tronscanapi.com/api/transaction?sort=-timestamp&count=true&limit=1&start=0&address=${addr}`, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    const latestTxData = await latestTxRes.json();
    const lastTxDate = latestTxData.data && latestTxData.data.length > 0 ? latestTxData.data[0].timestamp : null;
    
    let totalInUSDT = 0;
    let totalOutUSDT = 0;
    const uniqueWallets = new Set();
    
    const firstTransferRes = await fetch(`https://apilist.tronscanapi.com/api/token_trc20/transfers?limit=50&start=0&sort=-timestamp&count=true&relatedAddress=${addr}&contract_address=${usdtContract}`, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    const firstTransferData = await firstTransferRes.json();
    
    const totalUSDTTransfers = firstTransferData.total || 0;
    let transfers = firstTransferData.token_transfers || [];
    
    const maxPages = 10; 
    const fetchPromises = [];
    for (let i = 50; i < Math.min(totalUSDTTransfers, maxPages * 50); i += 50) {
       fetchPromises.push(
         fetch(`https://apilist.tronscanapi.com/api/token_trc20/transfers?limit=50&start=${i}&sort=-timestamp&count=true&relatedAddress=${addr}&contract_address=${usdtContract}`, { headers: { 'User-Agent': 'Mozilla/5.0' } })
         .then(res => res.json())
         .then(d => d.token_transfers || [])
         .catch(() => [])
       );
    }
    
    if (fetchPromises.length > 0) {
      const results = await Promise.all(fetchPromises);
      results.forEach(batch => {
        transfers = transfers.concat(batch);
      });
    }
    
    transfers.forEach(t => {
      const amount = parseFloat(t.quant) / Math.pow(10, t.tokenInfo.tokenDecimal);
      if (t.to_address === addr) {
        totalInUSDT += amount;
      } else if (t.from_address === addr) {
        totalOutUSDT += amount;
      }
      uniqueWallets.add(t.from_address);
      uniqueWallets.add(t.to_address);
    });
    
    uniqueWallets.delete(addr);
    uniqueWallets.delete('');
    
    console.log({
      balanceUSDT,
      totalTx,
      txIn,
      txOut,
      dateCreated,
      lastTxDate,
      totalInUSDT,
      totalOutUSDT,
      uniqueWalletsCount: uniqueWallets.size,
      transfersAnalyzed: transfers.length,
      totalUSDTTransfers
    });
  } catch (err) {
    console.error(err);
  }
}

fetchTronData('TMuA6YqfCeX8EhbfYEg5y7S4DqzSJireY9');
