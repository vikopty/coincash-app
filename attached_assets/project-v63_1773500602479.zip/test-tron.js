import https from 'https';

https.get('https://apilist.tronscanapi.com/api/account?address=TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t', (res) => {
  console.log('Tronscan Status:', res.statusCode);
  console.log('Tronscan CORS:', res.headers['access-control-allow-origin']);
}).on('error', (e) => {
  console.error(e);
});

https.get('https://api.trongrid.io/v1/accounts/TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t', (res) => {
  console.log('TronGrid Status:', res.statusCode);
  console.log('TronGrid CORS:', res.headers['access-control-allow-origin']);
}).on('error', (e) => {
  console.error(e);
});
