import https from 'https';

const testEndpoint = (host) => {
  https.get(`https://${host}/api/account?address=TX1D8G16jLftWzMhhzry2aUqWeGkSgqK1h`, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
    console.log(`${host} Status:`, res.statusCode);
  }).on('error', (e) => {
    console.error(`${host} Error:`, e.message);
  });
};

testEndpoint('apilist.tronscanapi.com');
testEndpoint('apilist.tronscan.org');
testEndpoint('api.tronscan.org');
