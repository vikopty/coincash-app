import https from 'https';

https.get('https://api.trongrid.io/v1/accounts/TX1D8G16jLftWzMhhzry2aUqWeGkSgqK1h/transactions/trc20?contract_address=TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t', (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => console.log('TronGrid response:', data.substring(0, 500)));
}).on('error', (e) => {
  console.error(e);
});
