import https from 'https';

https.get('https://api.tronscan.org/api/account?address=TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t', (res) => {
  console.log('Tronscan Org Status:', res.statusCode);
  console.log('Tronscan Org CORS:', res.headers['access-control-allow-origin']);
}).on('error', (e) => {
  console.error(e);
});
