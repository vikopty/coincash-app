console.log("Creating sed script...");
